// Zustand store for managing clientId context
import { create } from 'zustand';

// This file has been moved to src/store/clientStore.js
// Please refer to the new location for the client store implementation.

